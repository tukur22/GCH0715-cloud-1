var express = require('express')
var app = express();

var publicDir = require('path').join(__dirname,'/public');
app.use(express.static(publicDir));

//npm i handlebars consolidate --save
const engines = require('consolidate');
app.engine('hbs',engines.handlebars);
app.set('views','./views');
app.set('view engine','hbs');


//=> localhost:5000
app.get('/',function(req,res){
    //res.sendFile(__dirname + '/'+ 'public/' + 'home.html');
    res.render('index',{name:"Mom"});//call index.hbs with data: name->mom
})

var fs = require('fs');
//localhost:5000/listUsers
app.get('/listUsers',function(req,res){
    fs.readFile('user.txt','utf8',function(err,data){
        let reg = /[-;,\s]/
        let allNames = data.split(reg);
        let result = [];
        // for(i=0;i<allNames.length;i++){
        //     if (allNames[i].trim().length!=0)
        //         result.push(allNames[i]);
        // }
        result = allNames.filter(function(e){
            return e.trim().length >0;
        })
        res.render('listUser',{model:result})
    })
    //let data = ['phuong','minh','cuong','hai'];  
})

app.get('/cities',function(req,res){
    let cities = [
        {name: 'Los Angeles', population: 3792621},
        {name: 'New York', population: 8175133},
        {name: 'Chicago', population: 2695598},
        {name: 'Houston', population: 2099451},
        {name: 'Philadelphia', population: 1526006}
    ];
    res.render('cities',{model: cities})
})

var server = app.listen(5000);