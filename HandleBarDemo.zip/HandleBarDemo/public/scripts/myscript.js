function sayHi(msg){
    alert(`the message is ${msg}`)
}